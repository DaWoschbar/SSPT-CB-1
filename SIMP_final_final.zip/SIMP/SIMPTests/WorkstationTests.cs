﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NuGet.Frameworks;
using SIMP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIMP.Tests
{
    [TestClass()]
    public class WorkstationTests
    {
        [TestMethod()]
        public void DoWorkTest()
        {
            Workstation workstation = new Workstation();
            workstation.hostname = "localhost";
            workstation.department = "Accounting";
            workstation.owner = "Roman Schabus";
            Assert.IsTrue(workstation.DoWork());
        }
    }
}