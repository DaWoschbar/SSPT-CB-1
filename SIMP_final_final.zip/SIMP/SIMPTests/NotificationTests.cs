﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SIMP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIMP.Tests
{
    [TestClass()]
    public class NotificationTests
    {
        [TestMethod()]
        public void CallPersonTest()
        {
            Assert.IsTrue(Notification.CallPerson());
        }
    }
}