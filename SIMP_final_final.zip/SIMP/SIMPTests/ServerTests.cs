﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SIMP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIMP.Tests
{
    [TestClass()]
    public class ServerTests
    {
        [TestMethod()]
        public void InstallServiceTest()
        {
            Server server = new Server();
            bool res = server.InstallService(Service.Services.http);
            Assert.IsTrue(res);
        }
    }
}