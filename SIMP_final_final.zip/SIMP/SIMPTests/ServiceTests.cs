﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SIMP;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIMP.Tests
{
    [TestClass()]
    public class ServiceTests
    {
        [TestMethod()]
        public void ServiceCheckerTest()
        {
            Service service = new Service();
            bool res = service.ServiceChecker(Service.Services.http, "localhost");
            Assert.IsTrue(res);
        }
    }
}