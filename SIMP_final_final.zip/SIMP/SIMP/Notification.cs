﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIMP
{
    public static class Notification
    {
        //fields
        private static string phoneNumber = "+43 1234567";
        private static string mailaddress = "fhsupport@fhstp.ac.at";

        //properties
        public static string Mailaddress { get => mailaddress; set => mailaddress = value; }
        public static string PhoneNumber { get => phoneNumber; set => phoneNumber = value; }


        public static bool SendSMS()
        {
            Console.WriteLine("Sending sms to phone number " + phoneNumber);
            return true;
        }

        public static bool SendEmail()
        {
            Console.WriteLine("Sending mail to " + mailaddress);
            return true;
        }
        public static bool CallPerson()
        {
            Console.WriteLine("Calling the responsible IT Admin with the number: " + phoneNumber);
            return true;
        }
    }
}
