﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIMP
{
    public class Workstation : Device
    {
        private string ownerName = "Chief";
        private string departmentName = "IT";
        public string owner { get => ownerName; set => ownerName = value; }
        public string department { get => departmentName; set => departmentName = value; }

        public bool DoWork()
        {
            Console.WriteLine($"    > A letter is being written by {owner} with Microsoft Word!");
            Console.WriteLine("     > A Mail has been written with Outlook");
            Console.WriteLine($"    > Someone is surfing on orf.at from the department {department} ");
            return true;
        }
    }
}
