﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIMP
{
    public abstract class Device
    {
        public Guid ID { get; } = Guid.NewGuid();
        public string name { get; set; } = "";
        public string hostname { get; set; } = "";

        public void StartDevice()
        {
            Console.WriteLine("     > The device is being started!");
        }
    }
}
