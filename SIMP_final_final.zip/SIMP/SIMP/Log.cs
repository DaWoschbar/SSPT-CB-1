﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIMP
{
    public static class Log
    {
        public static string LogPath { get; set; } = "log.txt";

        public static void LogFile(string message)
        {
            File.AppendAllText(LogPath, $"{DateTime.Now}\t{message}{Environment.NewLine}");
            Console.WriteLine(message);
        }
    }
}
