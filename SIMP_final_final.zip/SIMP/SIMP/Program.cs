﻿using System.Runtime.CompilerServices;

namespace SIMP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Service svc = new Service();

            //TODO: Unit Tests
            #region generateObjects
            Printer HP = new Printer();
            HP.hostname = "PrinterAccounting";
            HP.name = "Printer first floor";
            HP.Print(@"C:\test.txt", Printer.PrintFormat.A4);

            Workstation Dell = new Workstation();
            Dell.hostname = "MA2712_Drews";
            Dell.department = "FIBU";
            Dell.DoWork();
            
            Server AppServer = new Server();
            AppServer.hostname = "appserver.local";
            AppServer.name = "HTTPWebserver";
            AppServer.DoLoadBalancing();
            PrintInfo("     > Installing HTTP-Service on Server..");

            if(!AppServer.InstallService(Service.Services.http))
                PrintError("Error: Service could not be installed!");
            #endregion

            try
            {
                for (int i = 0; i <= 3; i++)
                {
                    if (!svc.ServiceChecker(Service.Services.http, AppServer.hostname))
                    {
                        Notification.SendEmail();
                        break;
                    }
                    PrintSuccess("FHSTP Websiete ist online!");
                }

                for (int i = 0; i <= 3; i++)
                {
                    if (!svc.ServiceChecker(Service.Services.ping, AppServer.hostname))
                    {
                        Notification.SendEmail();
                        break;
                    }
                    PrintError($"{AppServer.hostname} could not be pinged");
                }

                //example of the smb and SMTP not implemented config
                svc.ServiceChecker(Service.Services.smb, AppServer.hostname);
                PrintError("Service SMB not implemented yet...");
                svc.ServiceChecker(Service.Services.smtp, AppServer.hostname);
                PrintError("Service SMTP not implemented yet...");
            }
            catch (Exception)
            {
                PrintError("Unknown error :c");
            }
        }

        private static void PrintError(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(msg);
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static void PrintInfo(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(msg);
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static void PrintSuccess(string msg)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(msg);
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}