﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIMP
{
   public class Printer : Device
    {
        private static bool colorable = true;

        public bool Colorable { get => colorable; }
        public enum PrintFormats
        {
            A3,
            A4,
            A5,
            A6
        }
        public void Print(string path, PrintFormats format)
        {
            switch (format)
            {
                case PrintFormats.A3:
                    break;
                case PrintFormats.A4:
                    break;
                case PrintFormats.A5:
                    break;
                case PrintFormats.A6:
                    break;
                default:
                    break;
            }
            Console.WriteLine($"The document from {path} is bring printed!");
        }
    }
}
