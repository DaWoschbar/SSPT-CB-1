﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIMP
{
    public class Server : Device
    {
        public List<Service.Services> runningServices { get; set; } = new List<Service.Services>();

        public void DoLoadBalancing()
        {
            Console.WriteLine("ein Service hier, das 2. Service auf einem 2. Server");
        }

        public bool InstallService(Service.Services svc)
        {
            runningServices.Add(svc);
            return true;
        }
    }
}
