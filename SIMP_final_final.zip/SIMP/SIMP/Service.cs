﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace SIMP
{
    public class Service
    {
        private int interval = 30;
        
        private DateTime lastChecked = DateTime.MinValue;
        private DateTime lastSuccessfull;
        private int failedCounter = 0;

        public int Interval { get => interval; set => interval = value; }
        public DateTime LastChecked { get => lastChecked; set => lastChecked = value; }
        public DateTime LastSuccessfull { get => lastSuccessfull; set => lastSuccessfull = value; }
        public int FailedCounter { get => failedCounter; }

        public enum Services
        {
            ping,
            http,
            smb,
            smtp
        }

        public bool ServiceChecker(Services svc, string hostname)
        {
            try
            {
                bool result = false;
                switch (svc)
                {
                    case Services.ping:
                        result = CheckPing(hostname);
                        break;
                    case Services.http:
                        result = CheckHttp(hostname);
                        break;
                    case Services.smb:
                        result = CheckSmb(hostname);
                        break;
                    case Services.smtp:
                        result = CheckSMTP(hostname);
                        break;
                    default:
                        break;
                }
                LastChecked = DateTime.Now;
                return result;
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        private bool CheckPing(string hostname)
        {
            try
            {
                Ping ping = new Ping();
                PingReply result = ping.Send(hostname);

                if (result.Status.ToString().ToLower() == "success")
                {
                    Log.LogFile("SUCCESS: Pinged " + hostname);
                    LastSuccessfull = DateTime.Now;
                    return true;
                }
                Log.LogFile("FAILED: Pinged " + hostname);
                failedCounter++;

                return false;
            }
            catch (PingException)
            {
                Log.LogFile("FAILED: Pinged " + hostname);
                failedCounter++;

                return false;
            }
            catch (Exception ex)
            {
                failedCounter++;
                throw new Exception(ex.Message);
            }
        }
        private bool CheckHttp(string hostname) 
        {
            try
            {
                string content = new WebClient().DownloadString($"https://cis.fhstp.ac.at/addons/STPCore/cis/login.php");

                Log.LogFile("SUCCESS: reached CIS website");
                LastSuccessfull = DateTime.Now;
                return true;
            }
            catch (WebException) 
            {
                Log.LogFile("ERROR: Could not reach webpage");
                failedCounter++;
                return false;
            }
            catch (Exception ex)
            {
                failedCounter++;
                throw new Exception(ex.Message);
            }
        }
        private bool CheckSmb(string hostname) 
        {
            try
            {
                Console.WriteLine("Checking if SMB is available...");
                Log.LogFile("INFO: Method not really implemented yet");
                failedCounter++;
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        private bool CheckSMTP(string hostname) 
        {
            try
            {
                Console.WriteLine("Checking if SMTP service is available...");
                Log.LogFile("INFO: Method not really implemented yet");
                failedCounter++;
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
